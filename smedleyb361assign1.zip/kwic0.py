from kwic import kwic0 as kwic
