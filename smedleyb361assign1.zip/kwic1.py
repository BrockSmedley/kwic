from kwic import kwic1 as kwic
