from kwic import kwic2 as kwic
