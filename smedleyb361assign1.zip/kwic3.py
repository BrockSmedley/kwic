from kwic import kwic3 as kwic
