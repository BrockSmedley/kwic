from kwic import kwic4 as kwic
