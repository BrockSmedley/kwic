from kwic import kwic5 as kwic
