from kwic import kwic6 as kwic
