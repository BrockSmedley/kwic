from kwic import kwic7 as kwic
