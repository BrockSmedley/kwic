from kwic import kwic8 as kwic
